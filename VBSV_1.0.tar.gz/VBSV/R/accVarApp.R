########### R function: accVarApp ##########

# For assessment of the accuracy of a variational
# approximate posterior density function.

# If type="Normal"            then parVec = (mean,variance)
# If type="Lognormal"         then parVec = (mean,variance)

# Last changed: 28/02/2023

accVarApp <- function(VBparVec,
                      MCsample,
                      type,
                      parName="",
                      plotDensities=TRUE,
                      parTrue=NULL,
                      nMC=10000){
  
  if (length(VBparVec)<3) {
    require("KernSmooth")
    require("ggplot2")
    
    parVec = VBparVec
    
    trapint <- function(xgrid, fgrid) 
    {
      ng <- length(xgrid)
      xvec <- xgrid[2:ng] - xgrid[1:(ng - 1)]
      fvec <- fgrid[1:(ng - 1)] + fgrid[2:ng]
      integ <- sum(xvec * fvec)/2
      return(integ)
    }
    
    MClower <- quantile(MCsample,0.0005)
    MCupper <- quantile(MCsample,0.9995)
    
    if (type=="Normal")
    {
      VAlower <- parVec[1] - qnorm(0.9995)*sqrt(parVec[2])
      VAupper <- parVec[1] + qnorm(0.9995)*sqrt(parVec[2])
    } 
    
    if (type=="Lognormal")
    {
      VAlower <- 0
      VAupper <- exp(parVec[1] + qnorm(0.9995)*sqrt(parVec[2]))
    } 
    
    xgLow <- min(MClower,VAlower) ; xgUpp <- max(MCupper,VAupper)
    xlimVal <- c(xgLow,xgUpp)
    
    xg <- seq(xgLow,xgUpp,length=1001) 
    
    if (type=="Normal") VApostg <- dnorm(xg,parVec[1],sqrt(parVec[2]))
    if (type=="Lognormal") VApostg <- dlnorm(xg,parVec[1],sqrt(parVec[2]))
    
    
    # Compute accuracy value:
    
    MCpostg <- bkde(MCsample,bandwidth=dpik(MCsample),
                    range.x=range(xg),gridsize=1001)$y
    accurVal <- round(100-50*trapint(xg,abs(MCpostg-VApostg)),2)
    
    if (plotDensities)
    {
      ylimVal <- range(c(VApostg,MCpostg))
      
      dfpl = data.frame(x=c(xg,xg),
                        y=c(VApostg,MCpostg),
                        Algo=rep(c("VB","MCMC"),each=length(xg)))
      pl = ggplot(data=dfpl,aes(x=x,y=y,col=Algo)) + theme_bw() +
        geom_line(size=1.2) + geom_hline(yintercept=0) +
        scale_color_manual(values=c("indianred","blue")) +
        annotate("text",
                 0.15*min(xlimVal)+0.85*max(xlimVal),
                 0.1*min(ylimVal)+0.9*max(ylimVal),
                 label=as.character(paste(accurVal,"%",sep="")),size=12) +
        annotate("text",
                 0.15*min(xlimVal)+0.85*max(xlimVal),
                 0.3*min(ylimVal)+0.8*max(ylimVal),
                 label="accuracy",size=7) +
        theme(text=element_text(size=20)) + ylab("") + xlab("")
      if (!is.null(parTrue)) {
        pl = pl + 
          geom_segment(aes(x=parTrue,xend=parTrue,y=0,yend=ylimVal[2]),linetype='dashed',col="black",alpha=0.6,size=1.2)
      }
      if (!is.null(parName)) {
        pl = pl + 
          ggtitle(parName)
      }
      plot(pl)
    }      
    
    return(accurVal)   
  }
  
  if (length(VBparVec)>3) {
    require("KernSmooth")
    require("ggplot2")
    
    VBsample = VBparVec
    
    trapint <- function(xgrid, fgrid) 
    {
      ng <- length(xgrid)
      xvec <- xgrid[2:ng] - xgrid[1:(ng - 1)]
      fvec <- fgrid[1:(ng - 1)] + fgrid[2:ng]
      integ <- sum(xvec * fvec)/2
      return(integ)
    }
    
    MClower <- quantile(MCsample,0.0005)
    MCupper <- quantile(MCsample,0.9995)
    
    VAlower <- quantile(VBsample,0.0005)
    VAupper <- quantile(VBsample,0.9995)
    
    xgLow <- min(MClower,VAlower) ; xgUpp <- max(MCupper,VAupper)
    xlimVal <- c(xgLow,xgUpp)
    
    xg <- seq(xgLow,xgUpp,length=1001) 
    
    # Compute accuracy value:
    
    VApostg <- bkde(VBsample,bandwidth=dpik(VBsample),
                    range.x=range(xg),gridsize=1001)$y
    MCpostg <- bkde(MCsample,bandwidth=dpik(MCsample),
                    range.x=range(xg),gridsize=1001)$y
    accurVal <- round(100-50*trapint(xg,abs(MCpostg-VApostg)),2)
    
    if (plotDensities)
    {
      ylimVal <- range(c(VApostg,MCpostg))
      
      dfpl = data.frame(x=c(xg,xg),
                        y=c(VApostg,MCpostg),
                        Algo=rep(c("VB","MCMC"),each=length(xg)))
      pl = ggplot(data=dfpl,aes(x=x,y=y,col=Algo)) + theme_bw() +
        geom_line(size=1.2) + geom_hline(yintercept=0) +
        scale_color_manual(values=c("indianred","blue")) +
        annotate("text",
                 0.15*min(xlimVal)+0.85*max(xlimVal),
                 0.1*min(ylimVal)+0.9*max(ylimVal),
                 label=as.character(paste(accurVal,"%",sep="")),size=12) +
        annotate("text",
                 0.15*min(xlimVal)+0.85*max(xlimVal),
                 0.3*min(ylimVal)+0.8*max(ylimVal),
                 label="accuracy",size=7) +
        theme(text=element_text(size=20)) + ylab("") + xlab("")
      if (!is.null(parTrue)) {
        pl = pl + 
          geom_segment(aes(x=parTrue,xend=parTrue,y=0,yend=ylimVal[2]),linetype='dashed',col="black",alpha=0.6,size=1.2)
      }
      if (!is.null(parName)) {
        pl = pl + 
          ggtitle(parName)
      }
      plot(pl)
    }      
    
    return(accurVal)   
  }
  
}

########### End of accVarApp ############

