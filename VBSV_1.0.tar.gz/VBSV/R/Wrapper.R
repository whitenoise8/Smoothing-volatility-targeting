VBSV = function(y,X=NULL,W=NULL,hyper=list(A=0.1,B=0.1,s2=100,s2beta=100),options=list(homo=FALSE,smooth=FALSE),Tol_Par=0.001,maxIt=500,Trace=0) {
  n = length(y)
  mod = NULL
  
  if (is.null(X)) Z = matrix(1,n,1)
  if (!is.null(X)) Z = cbind(matrix(1,n,1),X)
  
  if (is.null(W)) mod = hgmrfSVcov(y,Z,hyper,Tol_Par,maxIt,Trace)
  if (!is.null(W)) mod = smooth_hgmrfSVcov(y,Z,W,hyper,Tol_Par,maxIt,Trace)
  rownames(mod$par) = c("mu","rho","eta2")
  
  mod
}
