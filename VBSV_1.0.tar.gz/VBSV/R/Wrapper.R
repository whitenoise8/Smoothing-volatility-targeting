VBSV = function(y,X=NULL,W=NULL,hyper,options=list(homo=FALSE,smooth=FALSE),Tol_Par=0.001,maxIt=500,Trace=0) {
  n = length(y)
  mod = NULL
  
  if (is.null(W)) if (options$smooth==TRUE) print("Please provide matrix W!")
  if (!is.null(X)) if (options$homo==TRUE) print("Warning: homoskedastic approximation with covariates not implemented! X is ignored!")
  
  if (options$homo == FALSE) {
    if (is.null(X)) Z = matrix(1,n,1)
    if (!is.null(X)) Z = cbind(matrix(1,n,1),X)
    
    if (options$smooth==FALSE) mod = hgmrfSVcov(y,Z,hyper,Tol_Par,maxIt,Trace)
    if (options$smooth==TRUE) mod = smooth_hgmrfSVcov(y,Z,W,hyper,Tol_Par,maxIt,Trace)
    rownames(mod$par) = c("mu","rho","eta2")
  }
  if (options$homo == TRUE) {
    if (options$smooth==FALSE) mod = gmrfSV(y,hyper,Tol_Par,maxIt,Trace)
    if (options$smooth==TRUE) mod = smooth_gmrfSV(y,W,hyper,Tol_Par,maxIt,Trace)
    rownames(mod$par) = c("mu","rho","eta2")
  }
  
  mod
}
