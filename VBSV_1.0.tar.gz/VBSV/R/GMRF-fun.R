#-------- Some Functions for the Stochastic Volatility models ----------#

# Last Update -- 03 Jan 2022
# Author: Nicolas Bianco

#------------------------------------------------------------------------------#
#: Simulate SV model with/out covariates
sv_sim = function(n,mu,rho,sigma,beta=NULL) {
  
  h = rep(0,n+1)
  y = rep(0,n)
  
  if (is.null(beta)) {
    h[1] = rnorm(1,mu,sigma/sqrt(1-rho^2))
    
    for (t in 1:n) {
      h[t+1] = rnorm(1,mu+rho*(h[t]-mu),sigma)
      y[t] = rnorm(1,0,exp(h[t+1]/2))
    }
    
    out = list(y=y,h=h[-1],h0=h[1])
  }
  
  if (!is.null(beta)) {
    p = length(beta)
    
    X = matrix(rnorm(p*n),n,p)
    X[,1] = 1
    
    h[1] = rnorm(1,mu,sigma/sqrt(1-rho^2))
    
    for (t in 1:n) {
      h[t+1] = rnorm(1,mu+rho*(h[t]-mu),sigma)
      y[t] = rnorm(1,X[t,]%*%beta,exp(h[t+1]/2))
    }
    
    out = list(y=y,h=h[-1],h0=h[1],X=X)
  }
  
  out
}

#------------------------------------------------------------------------------#
#: Plot the log-volatility 
sv_plot = function(vb_mod,true_val=NULL,log=TRUE) {
  require(ggplot2)
  n = length(h)
 
  if (log==TRUE) {
  if (!is.null(vb_mod$tau2)) {
  vb_h = vb_mod$mu_q_h[-1]
  vb_lh = vb_mod$mu_q_h[-1]-1.96*sqrt(vb_mod$tau2)
  vb_uh = vb_mod$mu_q_h[-1]+1.96*sqrt(vb_mod$tau2)
  } 
  
  if (is.null(vb_mod$tau2)) {
    vb_h = vb_mod$mu_q_h[-1]
    vb_lh = vb_mod$mu_q_h[-1]-1.96*sqrt(vb_mod$sigma2_q_h[-1])
    vb_uh = vb_mod$mu_q_h[-1]+1.96*sqrt(vb_mod$sigma2_q_h[-1])
  } 
  
  if (is.null(true_val)) {
    dfpl = data.frame(y=vb_h,
                      ly = vb_lh,
                      uy = vb_uh,
                      x=1:n,
                      Method=rep("VB",n))
    
    pl = ggplot(data=dfpl,aes(y=y,x=x,col=Method)) + theme_bw() +
      geom_line(size=1) +
      geom_line(aes(x=x,y=ly,col=Method),linetype='dashed',size=0.6) +
      geom_line(aes(x=x,y=uy,col=Method),linetype='dashed',size=0.6) +
      scale_color_manual(values="blue") +
      ylab("") + xlab("") +
      theme(text=element_text(size=18),
            legend.position="top",
            legend.title=element_blank()) +
      guides(colour=guide_legend(override.aes=list(size=1.2)))
  }
  
  if (!is.null(true_val)) {
  dfpl = data.frame(y=c(h,vb_h),
                    ly = c(rep(NA,n),vb_lh),
                    uy = c(rep(NA,n),vb_uh),
                    x=rep(1:n,2),
                    Method=rep(c("True","VB"),each=n))
  
  pl = ggplot(data=dfpl,aes(y=y,x=x,col=Method)) + theme_bw() +
    geom_line(size=1) +
    geom_line(aes(x=x,y=ly,col=Method),linetype='dashed',size=0.6) +
    geom_line(aes(x=x,y=uy,col=Method),linetype='dashed',size=0.6) +
    scale_color_manual(values=c("grey","blue")) +
    ylab("") + xlab("") +
    theme(text=element_text(size=18),
          legend.position="none",
          legend.title=element_blank()) +
    guides(colour=guide_legend(override.aes=list(size=1.2)))
  }
  }
  
  if (log==FALSE) {
    require(TeachingDemos)
    if (!is.null(vb_mod$tau2)) {
      vb_h = exp(vb_mod$mu_q_h[-1]+1/2*vb_mod$tau2)
      mat_hpd = apply(matrix(vb_mod$mu_q_h[-1],n,1),1,function(x) hpd(qlnorm,meanlog=x,sdlog=sqrt(vb_mod$tau2)))
      vb_lh = mat_hpd[1,]
      vb_uh = mat_hpd[2,]
    } 
    
    if (is.null(vb_mod$tau2)) {
      vb_h = exp(vb_mod$mu_q_h[-1]+1/2*vb_mod$sigma2_q_h[-1])
      mat_hpd = apply(cbind(vb_mod$mu_q_h[-1],vb_mod$sigma2_q_h[-1]),1,function(x) hpd(qlnorm,meanlog=x[1],sdlog=sqrt(x[2])))
      vb_lh = mat_hpd[1,]
      vb_uh = mat_hpd[2,]
    } 
    
    if (is.null(true_val)) {
      dfpl = data.frame(y=vb_h,
                        ly = vb_lh,
                        uy = vb_uh,
                        x=1:n,
                        Method=rep("VB",n))
      
      pl = ggplot(data=dfpl,aes(y=y,x=x,col=Method)) + theme_bw() +
        geom_line(size=1) +
        geom_line(aes(x=x,y=ly,col=Method),linetype='dashed',size=0.6) +
        geom_line(aes(x=x,y=uy,col=Method),linetype='dashed',size=0.6) +
        scale_color_manual(values="blue") +
        ylab("") + xlab("") +
        theme(text=element_text(size=18),
              legend.position="top",
              legend.title=element_blank()) +
        guides(colour=guide_legend(override.aes=list(size=1.2)))
    }
    
    if (!is.null(true_val)) {
      dfpl = data.frame(y=c(exp(h),vb_h),
                        ly = c(rep(NA,n),vb_lh),
                        uy = c(rep(NA,n),vb_uh),
                        x=rep(1:n,2),
                        Method=rep(c("True","VB"),each=n))
      
      pl = ggplot(data=dfpl,aes(y=y,x=x,col=Method)) + theme_bw() +
        geom_line(size=1) +
        geom_line(aes(x=x,y=ly,col=Method),linetype='dashed',size=0.6) +
        geom_line(aes(x=x,y=uy,col=Method),linetype='dashed',size=0.6) +
        scale_color_manual(values=c("grey","blue")) +
        ylab("") + xlab("") +
        theme(text=element_text(size=18),
              legend.position="none",
              legend.title=element_blank()) +
        guides(colour=guide_legend(override.aes=list(size=1.2)))
    }
  }
  
  options(warn=-1)
  plot(pl)
  options(warn=0)
}

#------------------------------------------------------------------------------#
#: Optimal density for rho
q_rho = function(rho,alpha,beta,s2_inv,R=5000) {
  
  prec = alpha*s2_inv
  s = 1/sqrt(prec)
  m = beta/alpha
  
  rsim = rnorm(R,m,s)
  r = rsim[((rsim>-1)&(rsim<1))]
  
  k = 1/mean(sqrt((1-r*r)*2*pi/prec))
  
  k*sqrt(1-rho*rho)*exp(-1/2*prec*(rho-m)^2)
}

#------------------------------------------------------------------------------#
#: Simulate from optimal density of rho
rho_sim = function(n,alpha,beta,s2inv) {
  
  rho = NULL
  M = -optimize(function(x) -q_rho(x,alpha,beta,s2inv),c(-1,1))$objective
  
  while (length(rho)<n) {
    prop = runif(n)
    rho = c(rho,prop[runif(n)<q_rho(prop,alpha,beta,s2inv)/M*dunif(prop)])
  }
  
  rho[sample(1:length(rho),n)]
}

#------------------------------------------------------------------------------#
#: Predictive for h_{t+1} #: Da sistemare!
pred_h = function(N,mod) {
  
  #n = length(mod$mu_q_h)-1
  
  if (!is.null(mod$tau2)) {
    v2 = mod$tau2
  } 
  
  if (is.null(mod$tau2)) {
    v2 = mod$Sigma_q_h[n+1,n+1]
  }
  
  h_sim = rnorm(N,mod$mu_q_h[n+1],sqrt(v2))
  
  #s2eta_sim = 1/rgamma(N,mod$s2eta_par[1],mod$s2eta_par[2])
  #s2inv = mod$s2eta_par[1]/mod$s2eta_par[2]
  
  #c_sim = rnorm(N,mod$c_par[1],sqrt(mod$c_par[2]))
  #rho_sim = rho_sim(N,mod$rho_par[1],mod$rho_par[2],s2inv)
  
  rnorm(N,mod$par[1]+mod$par[2]*(h_sim-mod$par[1]),sqrt(mod$par[3]))
}


# Creates a Daubechies wavelet basis function
# design matrix for a given input vector "x".
ZDaub <- function(x,range.x=range(x),numLevels=6,filterNumber=5,
                  resolution=16384)
{
  # Load required package:
  
  library(wavethresh)
  
  # Check that x within support limits:
  
  if (any(x<range.x[1])|any(x>range.x[2]))
    stop("All abscissae should be within range.x values.")
  
  # Ensure that the number of levels is `allowable'.
  
  if (!any(numLevels==(1:10)))
    stop("Number of levels should be between 2 and 10.")
  
  # Ensure the resolution value is `allowable'.
  
  if (!any(resolution==(2^(10:20))))
    stop("Resolution value should be a power of 2, with the
              power between 10 and 20.")
  
  # Transform x to the unit interval and obtain variables
  # required for linear interpolation:
  
  xUnit <- (x - range.x[1])/(range.x[2] - range.x[1])
  xUres <- xUnit*resolution
  fXuRes <- floor(xUres)
  
  # Set filter and wavelet family  
  
  family <- "DaubExPhase"
  K <- 2^numLevels - 1
  
  # Create a dummy wavelet transform object
  
  wdObj <- wd(rep(0,resolution),filter.number=filterNumber,
              family="DaubExPhase")
  
  Z <- matrix(0,length(x),K)
  for (k in 1:K)
  {
    # Create wobj so that it contains the Kth basis
    # function of the Z matrix with `resolution' regularly 
    # spaced points:
    
    putCobj <- putC(wdObj,level=0,v=0)
    putCobj$D <- putCobj$D*0
    putCobj$D[resolution-k] <- 1
    
    # Obtain kth column of Z via linear interpolation
    # of the wr(putCobj) grid values:
    
    wtVec <- xUres - fXuRes
    wvVec <- wr(putCobj)
    wvVec <- c(wvVec,rep(wvVec[length(wvVec)],2))
    Z[,k] <- sqrt(resolution)*((1 - wtVec)*wvVec[fXuRes+1]
                               + wtVec*wvVec[fXuRes+2])
  }
  
  # Create column indices to impose "left-to-right" ordering
  # within the same level:
  
  newColInds <- 1
  for (ell in 1:(numLevels-1))
    newColInds <- c(newColInds,(2^(ell+1)-1):(2^(ell)))
  
  Z <- Z[,newColInds]
  
  return(Z)
}

