#-------- Some Functions for the Stochastic Volatility models ----------#

# Last Update -- 03 Jan 2022
# Author: Nicolas Bianco

#------------------------------------------------------------------------------#
#: Simulate SV model with/out covariates
sv_sim = function(n,mu,rho,eta2,beta=0) {
  
  h = rep(0,n+1)
  y = rep(0,n)
  
  sigma = sqrt(eta2)
  p = length(beta)
  
  if (p == 1) {
    h[1] = rnorm(1,mu,sigma/sqrt(1-rho^2))
    
    for (t in 1:n) {
      h[t+1] = rnorm(1,mu+rho*(h[t]-mu),sigma)
      y[t] = rnorm(1,beta,exp(h[t+1]/2))
    }
    
    out = list(y=y,h=h[-1],h0=h[1])
  }
  
  if (p > 1) {
    
    X = matrix(rnorm(p*n),n,p)
    X[,1] = 1
    
    h[1] = rnorm(1,mu,sigma/sqrt(1-rho^2))
    
    for (t in 1:n) {
      h[t+1] = rnorm(1,mu+rho*(h[t]-mu),sigma)
      y[t] = rnorm(1,X[t,]%*%beta,exp(h[t+1]/2))
    }
    
    out = list(y=y,h=h[-1],h0=h[1],X=X[,-1])
  }
  
  out
}

#------------------------------------------------------------------------------#
#: Plot the log-volatility 
sv_plot = function(vb_mod,true_val=NULL,log=TRUE) {
  require(ggplot2)
  n = length(vb_mod$mu_q_h[-1])
  
  if (log==TRUE) {
    
    vb_h = vb_mod$mu_q_h[-1]
    vb_lh = vb_mod$mu_q_h[-1]-1.96*sqrt(vb_mod$sigma2_q_h[-1])
    vb_uh = vb_mod$mu_q_h[-1]+1.96*sqrt(vb_mod$sigma2_q_h[-1])
    
    if (is.null(true_val)) {
      dfpl = data.frame(y = vb_h,
                        ly = vb_lh,
                        uy = vb_uh,
                        x = 1:n,
                        Method = rep("VB",n))
      
      pl = ggplot(data=dfpl,aes(y=y,x=x,col=Method)) + theme_bw() +
        geom_line(size=1) +
        geom_line(aes(x=x,y=ly,col=Method),linetype='dashed',size=0.6) +
        geom_line(aes(x=x,y=uy,col=Method),linetype='dashed',size=0.6) +
        scale_color_manual(values="blue") +
        ylab("") + xlab("") +
        theme(text=element_text(size=18),
              legend.position="top",
              legend.title=element_blank()) +
        guides(colour=guide_legend(override.aes=list(size=1.2)))
    }
    
    if (!is.null(true_val)) {
      h = true_val
      dfpl = data.frame(y = c(h,vb_h),
                        ly = c(rep(NA,n),vb_lh),
                        uy = c(rep(NA,n),vb_uh),
                        x = rep(1:n,2),
                        Method = rep(c("True","VB"),each=n))
      
      pl = ggplot(data=dfpl,aes(y=y,x=x,col=Method)) + theme_bw() +
        geom_line(size=1) +
        geom_line(aes(x=x,y=ly,col=Method),linetype='dashed',size=0.6) +
        geom_line(aes(x=x,y=uy,col=Method),linetype='dashed',size=0.6) +
        scale_color_manual(values=c("grey","blue")) +
        ylab("") + xlab("") +
        theme(text=element_text(size=18),
              legend.position="none",
              legend.title=element_blank()) +
        guides(colour=guide_legend(override.aes=list(size=1.2)))
    }
  }
  
  if (log==FALSE) {
    require(TeachingDemos)
    
    vb_h = exp(vb_mod$mu_q_h[-1]+1/2*vb_mod$sigma2_q_h[-1])
    mat_hpd = apply(cbind(vb_mod$mu_q_h[-1],vb_mod$sigma2_q_h[-1]),1,function(x) hpd(qlnorm,meanlog=x[1],sdlog=sqrt(x[2])))
    vb_lh = mat_hpd[1,]
    vb_uh = mat_hpd[2,]
    
    if (is.null(true_val)) {
      dfpl = data.frame(y = vb_h,
                        ly = vb_lh,
                        uy = vb_uh,
                        x = 1:n,
                        Method = rep("VB",n))
      
      pl = ggplot(data=dfpl,aes(y=y,x=x,col=Method)) + theme_bw() +
        geom_line(size=1) +
        geom_line(aes(x=x,y=ly,col=Method),linetype='dashed',size=0.6) +
        geom_line(aes(x=x,y=uy,col=Method),linetype='dashed',size=0.6) +
        scale_color_manual(values="blue") +
        ylab("") + xlab("") +
        theme(text=element_text(size=18),
              legend.position="top",
              legend.title=element_blank()) +
        guides(colour=guide_legend(override.aes=list(size=1.2)))
    }
    
    if (!is.null(true_val)) {
      h = true_val
      dfpl = data.frame(y = c(exp(h),vb_h),
                        ly = c(rep(NA,n),vb_lh),
                        uy = c(rep(NA,n),vb_uh),
                        x = rep(1:n,2),
                        Method = rep(c("True","VB"),each=n))
      
      pl = ggplot(data=dfpl,aes(y=y,x=x,col=Method)) + theme_bw() +
        geom_line(size=1) +
        geom_line(aes(x=x,y=ly,col=Method),linetype='dashed',size=0.6) +
        geom_line(aes(x=x,y=uy,col=Method),linetype='dashed',size=0.6) +
        scale_color_manual(values=c("grey","blue")) +
        ylab("") + xlab("") +
        theme(text=element_text(size=18),
              legend.position="none",
              legend.title=element_blank()) +
        guides(colour=guide_legend(override.aes=list(size=1.2)))
    }
  }
  
  options(warn=-1)
  plot(pl)
  return(pl)
  options(warn=0)
}

#------------------------------------------------------------------------------#
#: Predictive for h_{t+1} 
pred_h = function(N,mod,x_new=NULL) {
  library(mvtnorm)
  
  h_sim = rnorm(N,mod$mu_q_h[n+1],sqrt(mod$Sigma_q_h[n+1,n+1]))
  
  h_pred = rnorm(N,mod$par[1]+mod$par[2]*(h_sim-mod$par[1]),sqrt(mod$par[3]))
  
  if (!is.null(x_new)) x_new = c(1,x_new)
  if (is.null(x_new)) x_new = 1
  
  beta_sim = rmvnorm(N,mod$mu_q_beta,mod$Sigma_q_beta)
  y_pred = rnorm(N,apply(beta_sim,1,function(x) sum(x*x_new)),sqrt(exp(h_pred)))
  
  list(y=y_pred,
       h=h_pred)
}


