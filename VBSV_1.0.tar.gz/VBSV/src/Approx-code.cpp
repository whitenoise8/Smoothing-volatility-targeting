// [[Rcpp::depends(RcppEigen)]]
// [[Rcpp::depends(RcppNumerical)]]
// [[Rcpp::depends(RcppArmadillo)]]
#include <RcppArmadillo.h>
#include <math.h>  
#include <RcppNumerical.h>
#include <cmath>
#include <iostream>
#include <boost/math/common_factor.hpp> 
#include <boost/math/special_functions/bessel.hpp>
#include <boost/math/special_functions/digamma.hpp>

using namespace Numer;
using namespace std;
using namespace arma;
using namespace Rcpp;

// [[Rcpp::depends(BH)]]

arma::mat tridiag(double delem, double selem, double n) {
  
  arma::mat m = (1+delem)*eye(n,n);
  m(0,0) = 1;
  m(n-1,n-1) = 1;
  for (int i = 0; i < n-1; i++) {
    m(i,i+1) = -selem;
    m(i+1,i) = -selem;
  }
  
  return m;
}

arma::mat ar1cor(double gamma, double n) {
  arma::vec a = ones(n);
  for (int i = 1; i < n; i++) a(i) = pow(gamma,i);
  return toeplitz(a);
}

arma::mat invtridiag(arma::mat A) {
  int n = A.n_cols;
  
  arma::vec alpha = zeros(n);
  arma::vec gamma = zeros(n);
  
  alpha(0) = A(0,0);
  
  double a21 = A(1,0);
  for (int i = 1; i < n; i++) {
    gamma(i) = a21/alpha(i-1);
    alpha(i) = A(i,i)-a21*gamma(i);
  }
  
  arma::mat C = zeros(n,n);
  C(n-1,n-1) = 1/alpha(n-1);  
  for (int j = n-2; j > -1; j--) {
    C(n-1,j) = -a21/alpha(j)*C(n-1,j+1);
    C(j,n-1) = C(n-1,j);
  }
  for (int i = n-2; i > 0; i--) for (int j = i-1; j > -1; j--) {
    C(i,i) = 1/alpha(i)+pow(a21/alpha(i),2)*C(i+1,i+1);
    C(i,j) = -a21/alpha(j)*C(i,j+1);
    C(j,i) = C(i,j);
  }
  C(0,0) = 1/alpha(0)+pow(a21/alpha(0),2)*C(1,1);
  
  return C;
}

arma::vec rho_qmoments(double alpha, double beta, double s2_inv, int R = 5000) {
  
  double prec = alpha*s2_inv;
  double s = 1/sqrt(prec);
  double m = beta/alpha;
  
  arma::vec rsim = rnorm(R,m,s);
  arma::vec r = rsim(find((rsim>-1)&&(rsim<1)));
  
  double k = 1/mean(sqrt((1-r%r)*2*datum::pi/prec));
  
  arma::vec moments = zeros(2); 
  moments(0) = mean(k*r%sqrt((1-r%r)*2*datum::pi/prec));
  moments(1) = mean(k*r%r%sqrt((1-r%r)*2*datum::pi/prec));
  
  return moments;
}

Rcpp::List wand2014(arma::vec fold,
                    arma::mat Sold,
                    arma::vec s2old,
                   arma::vec s,
                   arma::vec qparam,
                   double Tol = 1e-3) {
  
  double n = s.n_elem;
  arma::vec i = ones(n+1);
  i(0) = 0;
  arma::vec splus = zeros(n+1);
  splus(span(1,n)) = s;
  int p = n+1;
  
  double mu_q_c = qparam(0);
  double mu_q_rho = qparam(1);
  double mu_q_rho2 = qparam(2);
  double mu_q_s2eta_inv = qparam(3);
  arma::mat mu_q_Q = tridiag(mu_q_rho2,mu_q_rho,n+1);
  
  int conv = 1;
  int nIt = 0;
  
  while (conv == 1) {
    nIt = nIt + 1;
    
    arma::vec dvec = splus%exp(-fold+0.5*s2old);
    arma::vec ups = -0.5*i +0.5*dvec -mu_q_s2eta_inv*mu_q_Q*(fold-mu_q_c);
      
    arma::mat invSnew = -0.5*diagmat(dvec) -mu_q_s2eta_inv*mu_q_Q;
    arma::mat Snew = -invtridiag(invSnew);
    arma::mat fnew = fold + Snew*ups;
      
    double delta = max(abs(fold-fnew));
      
    if (delta < Tol) conv = 0;
      
    fold = fnew;
    Sold = Snew;
    s2old = Snew.diag();
  }
  
  return Rcpp::List::create(
    Rcpp::Named("f") = fold,
    Rcpp::Named("S") = Sold,
    Rcpp::Named("s2") = s2old,
    Rcpp::Named("iter") = nIt,
    Rcpp::Named("convergence") = conv
  );
}


Rcpp::List wand2014W(arma::vec fold,
                     arma::mat Sold,
                     arma::vec s2old,
                     arma::vec s,
                     arma::mat X,
                     arma::vec qparam,
                     double Tol = 1e-2,
                     double maxf = 10) {
  
  double n = s.n_elem;
  int p = X.n_cols;
  arma::vec i = ones(n+1);
  i(0) = 0;
  arma::vec splus = zeros(n+1);
  splus(span(1,n)) = s;
  
  arma::mat Xpl = inv_sympd(X.t()*X)*X.t();
  
  double mu_q_c = qparam(0);
  double mu_q_rho = qparam(1);
  double mu_q_rho2 = qparam(2);
  double mu_q_s2eta_inv = qparam(3);
  arma::mat mu_q_Q = tridiag(mu_q_rho2,mu_q_rho,n+1);
  
  int conv = 1;
  int nIt = 0;
  
  while (conv == 1) {
    nIt = nIt + 1;
    
    arma::vec dvec = splus%exp(-X*fold+0.5*s2old);
    arma::vec ups = -0.5*i +0.5*dvec -mu_q_s2eta_inv*mu_q_Q*(X*fold-mu_q_c);
    
    arma::mat invSnew = -0.5*diagmat(dvec) -mu_q_s2eta_inv*mu_q_Q;
    arma::mat Snew = -invtridiag(invSnew);
    arma::mat fnew = fold + Xpl*Snew*ups;
    
    fnew(find(abs(fnew)>maxf)) = sign(fnew(find(abs(fnew)>maxf)))*maxf;
    
    double delta = max(abs(fold-fnew));
    
    if (delta < Tol) conv = 0;
    
    fold = fnew;
    Sold = Snew;
    s2old = Snew.diag();
  }
  
  return Rcpp::List::create(
    Rcpp::Named("f") = fold,
    Rcpp::Named("S") = Sold,
    Rcpp::Named("s2") = s2old,
    Rcpp::Named("iter") = nIt,
    Rcpp::Named("convergence") = conv
  );
}


arma::vec grad_tridiag_psi(arma::vec par,
                           arma::vec s,
                           arma::vec qparam) {
  
  double n = s.n_elem;
  arma::vec i = ones(n+1);
  i(0) = 0;
  arma::vec splus = zeros(n+1);
  splus(span(1,n)) = s;
  int p = n+1;
  
  double mu_q_c = qparam(0);
  double mu_q_rho = qparam(1);
  double mu_q_rho2 = qparam(2);
  double mu_q_s2eta_inv = qparam(3);
  arma::mat mu_q_Q = tridiag(mu_q_rho2,mu_q_rho,n+1);
  
  arma::vec f = par(span(0,p-1));
  double tau2 = par(p);
  double gamma = par(p+1);
  
  arma::vec grad = zeros(p+2);
  
  arma::vec dvec = splus%exp(-f+0.5*tau2);
  grad(span(0,p-1)) = -0.5*i +0.5*dvec -mu_q_s2eta_inv*mu_q_Q*(f-mu_q_c);
  
  grad(p) = -0.25*sum(dvec) -
    0.5*mu_q_s2eta_inv*(2.0+(1+mu_q_rho2)*(n-1)-2.0*n*gamma*mu_q_rho) +
    0.5*(n+1.0)/tau2;
  
  grad(p+1) = tau2*mu_q_s2eta_inv*n*mu_q_rho-n*gamma/(1.0-gamma*gamma);
  
  return grad;
}


arma::mat inv_tridiag_hess_psi(arma::vec par,
                               arma::vec s,
                               arma::vec qparam) {
  
  double n = s.n_elem;
  arma::vec splus = zeros(n+1);
  splus(span(1,n)) = s;
  int p = n+1;
  
  double mu_q_c = qparam(0);
  double mu_q_rho = qparam(1);
  double mu_q_rho2 = qparam(2);
  double mu_q_s2eta_inv = qparam(3);
  arma::mat mu_q_Q = tridiag(mu_q_rho2,mu_q_rho,n+1);
  
  arma::vec f = par(span(0,p-1));
  double tau2 = par(p);
  double gamma = par(p+1);
  
  arma::mat H = zeros(p+2,p+2);
  
  arma::vec dvec = splus%exp(-f+0.5*tau2);
  H.submat(0,0,p-1,p-1) = -0.5*diagmat(dvec) -mu_q_s2eta_inv*mu_q_Q;
  
  H(p,p) = -0.125*sum(dvec)-0.5*(n+1)/pow(tau2,2);
  
  H(p+1,p+1) = -n*(1+gamma*gamma)/pow(1-gamma*gamma,2);
  
  H.submat(0,p,p-1,p) = 0.25*dvec;
  H.submat(p,0,p,p-1) = 0.25*dvec.t();
  
  H(p,p+1) = H(p+1,p) = n*mu_q_rho*mu_q_s2eta_inv;
  
  arma::mat Ainv = invtridiag(H.submat(0,0,p-1,p-1));
  
  arma::mat invSchur = H.submat(p,p,p+1,p+1);
  invSchur(0,0) = invSchur(0,0) + 0.25*0.25*as_scalar(dvec.t()*Ainv*dvec);
  arma::mat Schur = inv(invSchur);
  
  arma::mat Hinv21 = 0.25*Ainv*dvec*Schur.row(0);
  
  arma::mat Hinv = zeros(p+2,p+2);
  
  Hinv.submat(0,0,p-1,p-1) = Ainv+0.25*Hinv21.col(0)*dvec.t()*Ainv;
  Hinv.submat(0,p,p-1,p+1) = -Hinv21;
  Hinv.submat(p,0,p+1,p-1) = -Hinv21.t();
  Hinv.submat(p,p,p+1,p+1) = Schur;
  
  return Hinv;
}


Rcpp::List opt_tridiag_psi(arma::vec par0,
                           arma::vec s,
                           arma::vec qparam,
                           double tol = 1e-2, 
                           int maxIt = 100, 
                           double maxf = 10) {
  int conv = 1;
  int it = 0;
  
  int n = s.n_elem;
  int p = n+1;
  
  arma::vec par = par0;
  
  while (conv == 1) {
    it = it + 1;
    
    arma::vec dpsi = grad_tridiag_psi(par0,s,qparam);
    arma::mat Hinv = inv_tridiag_hess_psi(par0,s,qparam);
    
    par = par0 - Hinv*dpsi;
    par(find(abs(par)>maxf)) = sign(par(find(abs(par)>maxf)))*maxf;
    
    if (par(p) < 0) par(p) = 1e-3;
    if (par(p+1) < -1+1e-3) par(p+1) = -1+1e-3;
    if (par(p+1) > 1-1e-3) par(p+1) = 1-1e-3;
    
    double delta = max(abs((par-par0)/par0));
    if (it > 1) if (delta < tol) conv = 0;
    par0 = par;
  }
  
  return Rcpp::List::create(
    Rcpp::Named("par") = par,
    Rcpp::Named("iter") = it,
    Rcpp::Named("convergence") = conv
  );
}

arma::vec grad_psiW(arma::vec par,
                    arma::vec s,
                    arma::mat X,
                    arma::vec qparam) {
  
  double n = s.n_elem;
  arma::vec i = ones(n);
  arma::mat X1 = X;
  X1.shed_row(0);
  int p = X1.n_cols;
  
  double mu_q_c = qparam(0);
  double mu_q_rho = qparam(1);
  double mu_q_rho2 = qparam(2);
  double mu_q_s2eta_inv = qparam(3);
  arma::mat mu_q_Q = tridiag(mu_q_rho2,mu_q_rho,n+1);
  
  arma::vec f = par(span(0,p-1));
  double tau2 = par(p);
  double gamma = par(p+1);
  
  arma::vec grad = zeros(p+2);
  
  arma::vec dvec = s%exp(-X1*f+0.5*tau2);
  grad(span(0,p-1)) = -0.5*X1.t()*i +0.5*X1.t()*dvec -
    mu_q_s2eta_inv*X.t()*mu_q_Q*(X*f-mu_q_c);
  
  grad(p) = -0.25*sum(dvec) -
    0.5*mu_q_s2eta_inv*(2.0+(1+mu_q_rho2)*(n-1)-2.0*n*gamma*mu_q_rho) +
    0.5*(n+1.0)/tau2;
  
  grad(p+1) = tau2*mu_q_s2eta_inv*n*mu_q_rho-n*gamma/(1.0-gamma*gamma);
  
  return grad;
}


arma::mat inv_hess_psiW(arma::vec par,
                        arma::vec s,
                        arma::mat X,
                        arma::vec qparam,
                        arma::mat XQX) {
  
  double n = s.n_elem;
  arma::vec i = ones(n);
  arma::mat X1 = X;
  X1.shed_row(0);
  int p = X1.n_cols;
  
  double mu_q_c = qparam(0);
  double mu_q_rho = qparam(1);
  double mu_q_rho2 = qparam(2);
  double mu_q_s2eta_inv = qparam(3);
  
  arma::vec f = par(span(0,p-1));
  double tau2 = par(p);
  double gamma = par(p+1);
  
  arma::mat H = zeros(p+2,p+2);
  
  arma::vec dvec = s%exp(-X1*f+0.5*tau2);
  H.submat(0,0,p-1,p-1) = -0.5*X1.t()*diagmat(dvec)*X1 -
    mu_q_s2eta_inv*XQX;
  
  H(p,p) = -0.125*sum(dvec)-0.5*(n+1)/pow(tau2,2);
  
  H(p+1,p+1) = -n*(1+gamma*gamma)/pow(1-gamma*gamma,2);
  
  H.submat(0,p,p-1,p) = 0.25*X1.t()*dvec;
  H.submat(p,0,p,p-1) = H.submat(0,p,p-1,p).t();
  
  H(p,p+1) = H(p+1,p) = n*mu_q_rho*mu_q_s2eta_inv;
  
  return inv(H);
}


Rcpp::List opt_psiW(arma::vec par0,
                    arma::vec s,
                    arma::mat X,
                    arma::vec qparam,
                    arma::mat XQX,
                    double tol = 1e-2, 
                    int maxIt = 100, 
                    double maxf = 10) {
  int conv = 1;
  int it = 0;
  
  int n = s.n_elem;
  int p = X.n_cols;
  
  arma::vec par = par0;
  
  while (conv == 1) {
    it = it + 1;
    
    arma::vec dpsi = grad_psiW(par0,s,X,qparam);
    arma::mat Hinv = inv_hess_psiW(par0,s,X,qparam,XQX);
    
    par = par0 - Hinv*dpsi;
    par(find(abs(par)>maxf)) = sign(par(find(abs(par)>maxf)))*maxf;
    
    if (par(p) < 0) par(p) = 1e-3;
    if (par(p+1) < -1+1e-3) par(p+1) = -1+1e-3;
    if (par(p+1) > 1-1e-3) par(p+1) = 1-1e-3;
    
    double delta = max(abs((par-par0)/par0));
    if (it > 1) if (delta < tol) conv = 0;
    par0 = par;
  }
  
  return Rcpp::List::create(
    Rcpp::Named("par") = par,
    Rcpp::Named("iter") = it,
    Rcpp::Named("convergence") = conv
  );
}

Rcpp::List gmrfSV(arma::vec y, 
                  Rcpp::List hyper,
                  double Tol_Par = 1e-2,
                  int maxIt = 500,
                  int Trace = 0) {
  
  arma::vec s = pow(y,2);
  double n = y.n_elem;
  double p = n+1;
  
  double A = hyper["A"];
  double B = hyper["B"];
  double s2 = hyper["s2"];
  
  arma::vec mu_q_h = zeros(p);
  double gamma = 0;
  double tau2 = 0;
  
  double mu_q_c = 0;
  double sigma2_q_c = 1;
  double mu_q_rho = 0.8;
  double mu_q_rho2 = 0.6;
  double mu_q_s2eta_inv = 3;
  double mu_q_s2eta = 3;
  
  arma::vec par0 = zeros(p+2);
  par0(p) = 0.8;
  par0(p+1) = 0.8;
  
  arma::vec parOld = zeros(n+4);
  parOld(span(0,n)) = mu_q_h;
  parOld(n+1) = mu_q_c;
  parOld(n+2) = mu_q_rho;
  parOld(n+3) = mu_q_s2eta;
  
  int conv = 0;
  int it = 0;
  
  while (conv==0) {
    it = it + 1;
    
    arma::vec qparam = zeros(4);
    qparam(0) = mu_q_c;
    qparam(1) = mu_q_rho;
    qparam(2) = mu_q_rho2;
    qparam(3) = mu_q_s2eta_inv;
    
    arma::mat mu_q_Qtilde = tridiag(mu_q_rho2,mu_q_rho,n+1);
    
    Rcpp::List opt_out = opt_tridiag_psi(par0,s,qparam);
    arma::vec pars = opt_out["par"];
    par0 = pars;
    
    mu_q_h = pars(span(0,p-1));
    tau2 = pars(p);
    gamma = pars(p+1);
    
    sigma2_q_c = 1.0/((2.0*(1-mu_q_rho)+(n-1)*(1.0+mu_q_rho2-2.0*mu_q_rho))*mu_q_s2eta_inv+1.0/s2);
    mu_q_c = sigma2_q_c*mu_q_s2eta_inv*((1.0-mu_q_rho)*(mu_q_h(0)+mu_q_h(n))+(1.0+mu_q_rho2-2.0*mu_q_rho)*sum(mu_q_h(span(1,n-1))));
    
    double A_q_eta = A + 0.5*(n+1);
    arma::vec sq_mu_h = pow(mu_q_h(span(1,n-1))-mu_q_c,2);
    arma::vec cross_mu_h = (mu_q_h(span(0,n-1))-mu_q_c)%(mu_q_h(span(1,n))-mu_q_c);
    double B_q_eta = B + 0.5*(pow(mu_q_h(0)-mu_q_c,2)+pow(mu_q_h(n)-mu_q_c,2)+(1+mu_q_rho2)*sum(sq_mu_h) -
                              2.0*mu_q_rho*sum(cross_mu_h) +
                              tau2*(2.0+(1.0+mu_q_rho2)*(n-1.0)-2.0*n*gamma*mu_q_rho) +
                              sigma2_q_c*(2.0*(1.0-mu_q_rho)+(n-1.0)*(1.0+mu_q_rho2-2.0*mu_q_rho)));
    mu_q_s2eta_inv = A_q_eta/B_q_eta;
    mu_q_s2eta = B_q_eta/(A_q_eta-1);
    
    double alpha = sum(sq_mu_h+sigma2_q_c+tau2);
    double beta = sum(cross_mu_h+sigma2_q_c+tau2*gamma);
    
    arma::vec out_q_rho = rho_qmoments(alpha,beta,mu_q_s2eta_inv);
    mu_q_rho = out_q_rho(0);
    mu_q_rho2 = out_q_rho(1);
    
    arma::vec parNew = zeros(n+4);
    parNew(span(0,n)) = mu_q_h;
    parNew(n+1) = mu_q_c;
    parNew(n+2) = mu_q_rho;
    parNew(n+3) = mu_q_s2eta;  
    
    if (it > 1) {
      double delta = max(abs((parNew-parOld)/parOld));
      if (delta < Tol_Par) conv = 1;
      if (Trace == 1) cout << "iter:" << it << " error:" << delta << endl;
    }
    if (it > maxIt) conv = 1;
    
    parOld = parNew;
  }
  
  arma::vec theta = zeros(3);
  theta(0) = mu_q_c;
  theta(1) = mu_q_rho;
  theta(2) = mu_q_s2eta;
  
  return Rcpp::List::create(
    Rcpp::Named("mu_q_h") = mu_q_h,
    Rcpp::Named("tau2") = tau2,
    Rcpp::Named("gamma") = gamma,
    Rcpp::Named("par") = theta
  );
}

Rcpp::List smooth_gmrfSV(arma::vec y, 
                         arma::mat X,
                         Rcpp::List hyper,
                         double Tol_Par = 1e-2,
                         int maxIt = 500,
                         int Trace = 0) {
  
  arma::vec s = pow(y,2);
  double n = y.n_elem;
  double p = X.n_cols;
  
  double A = hyper["A"];
  double B = hyper["B"];
  double s2 = hyper["s2"];
  
  arma::vec mu_q_h = zeros(n+1);
  arma::vec f = zeros(p);
  double gamma = 0;
  double tau2 = 0;
  
  double mu_q_c = 0;
  double sigma2_q_c = 1;
  double mu_q_rho = 0.8;
  double mu_q_rho2 = 0.6;
  double mu_q_s2eta_inv = 3;
  double mu_q_s2eta = 3;
  
  arma::vec par0 = zeros(p+2);
  par0(p) = 0.8;
  par0(p+1) = 0.8;
  
  arma::vec parOld = zeros(p+3);
  parOld(p) = mu_q_c;
  parOld(p+1) = mu_q_rho;
  parOld(p+2) = mu_q_s2eta;
  
  int conv = 0;
  int it = 0;
  while (conv==0) {
    it = it + 1;
    
    arma::vec qparam = zeros(4);
    qparam(0) = mu_q_c;
    qparam(1) = mu_q_rho;
    qparam(2) = mu_q_rho2;
    qparam(3) = mu_q_s2eta_inv;
    
    arma::mat mu_q_Qtilde = tridiag(mu_q_rho2,mu_q_rho,n+1);
    arma::mat XQX = X.t()*mu_q_Qtilde*X;
    
    Rcpp::List opt_out = opt_psiW(par0,s,X,qparam,XQX);
    arma::vec pars = opt_out["par"];
    par0 = pars;
    
    f = pars(span(0,p-1));
    mu_q_h = X*f;
    tau2 = pars(p);
    gamma = pars(p+1);
    
    sigma2_q_c = 1.0/((2.0*(1-mu_q_rho)+(n-1)*(1.0+mu_q_rho2-2.0*mu_q_rho))*mu_q_s2eta_inv+1.0/s2);
    mu_q_c = sigma2_q_c*mu_q_s2eta_inv*((1.0-mu_q_rho)*(mu_q_h(0)+mu_q_h(n))+(1.0+mu_q_rho2-2.0*mu_q_rho)*sum(mu_q_h(span(1,n-1))));
    
    double A_q_eta = A + 0.5*(n+1);
    arma::vec sq_mu_h = pow(mu_q_h(span(1,n-1))-mu_q_c,2);
    arma::vec cross_mu_h = (mu_q_h(span(0,n-1))-mu_q_c)%(mu_q_h(span(1,n))-mu_q_c);
    double B_q_eta = B + 0.5*(pow(mu_q_h(0)-mu_q_c,2)+pow(mu_q_h(n)-mu_q_c,2)+(1+mu_q_rho2)*sum(sq_mu_h) -
                              2.0*mu_q_rho*sum(cross_mu_h) +
                              tau2*(2.0+(1.0+mu_q_rho2)*(n-1.0)-2.0*n*gamma*mu_q_rho) +
                              sigma2_q_c*(2.0*(1.0-mu_q_rho)+(n-1.0)*(1.0+mu_q_rho2-2.0*mu_q_rho)));
    mu_q_s2eta_inv = A_q_eta/B_q_eta;
    mu_q_s2eta = B_q_eta/(A_q_eta-1);
    
    double alpha = sum(sq_mu_h+sigma2_q_c+tau2);
    double beta = sum(cross_mu_h+sigma2_q_c+tau2*gamma);
    
    arma::vec out_q_rho = rho_qmoments(alpha,beta,mu_q_s2eta_inv);
    mu_q_rho = out_q_rho(0);
    mu_q_rho2 = out_q_rho(1);
    
    arma::vec parNew = zeros(p+3);
    parNew(span(0,p-1)) = f;
    parNew(p) = mu_q_c;
    parNew(p+1) = mu_q_rho;
    parNew(p+2) = mu_q_s2eta;   
    
    if (it > 1) {
      double delta = max(abs((parNew-parOld)/parOld));
      if (delta < Tol_Par) conv = 1;
      if (Trace == 1) cout << "iter:" << it << " error:" << delta << endl;
    }
    if (it > maxIt) conv = 1;
    
    parOld = parNew;
  }
  
  arma::vec theta = zeros(3);
  theta(0) = mu_q_c;
  theta(1) = mu_q_rho;
  theta(2) = mu_q_s2eta;
  
  return Rcpp::List::create(
    Rcpp::Named("mu_q_h") = mu_q_h,
    Rcpp::Named("tau2") = tau2,
    Rcpp::Named("gamma") = gamma,
    Rcpp::Named("par") = theta
  );
}

// [[Rcpp::export]]
Rcpp::List hgmrfSVcov(arma::vec y, 
                   arma::mat X,
                  Rcpp::List hyper,
                  double Tol_Par = 1e-2,
                  int maxIt = 500,
                  int Trace = 0) {
  
  arma::vec s = pow(y,2);
  double n = y.n_elem;
  double p = n+1;
  double K = X.n_cols;
  
  double A = hyper["A"];
  double B = hyper["B"];
  double s2 = hyper["s2"];
  double s2beta = hyper["s2beta"];
  
  arma::vec mu_q_h = zeros(p);
  arma::mat Sigma_q_h = eye(p,p);
  arma::vec sigma2_q_h = ones(p);

  double mu_q_c = 0;
  double sigma2_q_c = 1;
  double mu_q_rho = 0.8;
  double mu_q_rho2 = 0.6;
  double mu_q_s2eta_inv = 3;
  double mu_q_s2eta = 3;
  
  arma::vec mu_q_beta = X.t()*y/n;
  arma::mat Sigma_q_beta = ones(K,K);
  
  arma::vec parOld = zeros(K+3);
  parOld(span(0,K-1)) = mu_q_beta;
  parOld(K) = mu_q_c;
  parOld(K+1) = mu_q_rho;
  parOld(K+2) = mu_q_s2eta;
  
  int conv = 0;
  int it = 0;
  
  while (conv==0) {
    it = it + 1;
    
    arma::vec qparam = zeros(4);
    qparam(0) = mu_q_c;
    qparam(1) = mu_q_rho;
    qparam(2) = mu_q_rho2;
    qparam(3) = mu_q_s2eta_inv;
    
    arma::mat mu_q_Qtilde = tridiag(mu_q_rho2,mu_q_rho,n+1);
    
    arma::vec trBXX = zeros(n);
    for (int t = 0; t < n; t++) trBXX(t) = trace(Sigma_q_beta*X.row(t).t()*X.row(t));
    arma::vec mu_q_s = pow(y-X*mu_q_beta,2) + trBXX;

    Rcpp::List opt_out = wand2014(mu_q_h,Sigma_q_h,sigma2_q_h,
                                  mu_q_s,qparam);
    arma::vec fh = opt_out["f"];
    arma::mat Sh = opt_out["S"];
    arma::vec sh = opt_out["s2"];
    
    mu_q_h = fh;
    Sigma_q_h = Sh;
    sigma2_q_h = sh;
    
    sigma2_q_c = 1.0/((2.0*(1-mu_q_rho)+(n-1)*(1.0+mu_q_rho2-2.0*mu_q_rho))*mu_q_s2eta_inv+1.0/s2);
    mu_q_c = sigma2_q_c*mu_q_s2eta_inv*((1.0-mu_q_rho)*(mu_q_h(0)+mu_q_h(n))+(1.0+mu_q_rho2-2.0*mu_q_rho)*sum(mu_q_h(span(1,n-1))));
    
    double A_q_eta = A + 0.5*(n+1);
    arma::vec sq_mu_h = pow(mu_q_h(span(1,n-1))-mu_q_c,2);
    arma::vec cross_mu_h = (mu_q_h(span(0,n-1))-mu_q_c)%(mu_q_h(span(1,n))-mu_q_c);
    double B_q_eta = B + 0.5*(pow(mu_q_h(0)-mu_q_c,2)+pow(mu_q_h(n)-mu_q_c,2)+(1+mu_q_rho2)*sum(sq_mu_h) -
                              2.0*mu_q_rho*sum(cross_mu_h) +
                              (sigma2_q_h(0)+sigma2_q_h(n)+(1+mu_q_rho2)*sum(sigma2_q_h(span(1,n-1)))-2*mu_q_rho*sum(Sigma_q_h.diag(1))) +
                              sigma2_q_c*(2.0*(1.0-mu_q_rho)+(n-1.0)*(1.0+mu_q_rho2-2.0*mu_q_rho)));
    mu_q_s2eta_inv = A_q_eta/B_q_eta;
    mu_q_s2eta = B_q_eta/(A_q_eta-1);
      
    double alpha = sum(sq_mu_h+sigma2_q_c+sigma2_q_h(span(1,n-1)));
    double beta = sum(cross_mu_h+sigma2_q_c+Sigma_q_h.diag(1));
    
    arma::vec out_q_rho = rho_qmoments(alpha,beta,mu_q_s2eta_inv);
    mu_q_rho = out_q_rho(0);
    mu_q_rho2 = out_q_rho(1);
    
    arma::mat H = diagmat(exp(-mu_q_h(span(1,n))+0.5*sigma2_q_h(span(1,n))));
    Sigma_q_beta = inv_sympd(X.t()*H*X+1/s2beta*ones(K,K));
    mu_q_beta = Sigma_q_beta*X.t()*H*y;
    
    arma::vec parNew = zeros(K+3);
    parNew(span(0,K-1)) = mu_q_beta;
    parNew(K) = mu_q_c;
    parNew(K+1) = mu_q_rho;
    parNew(K+2) = mu_q_s2eta;  
    
    if (it > 1) {
      double delta = max(abs((parNew-parOld)/parOld));
      if (delta < Tol_Par) conv = 1;
      if (Trace == 1) cout << "iter:" << it << " error:" << delta << endl;
    }
    if (it > maxIt) conv = 1;
    
    parOld = parNew;
  }
  
  arma::vec theta = zeros(3);
  theta(0) = mu_q_c;
  theta(1) = mu_q_rho;
  theta(2) = mu_q_s2eta;
  
  return Rcpp::List::create(
    Rcpp::Named("mu_q_h") = mu_q_h,
    Rcpp::Named("Sigma_q_h") = Sigma_q_h,
    Rcpp::Named("sigma2_q_h") = sigma2_q_h,
    Rcpp::Named("mu_q_beta") = mu_q_beta,
    Rcpp::Named("Sigma_q_beta") = Sigma_q_beta,
    Rcpp::Named("par") = theta
  );
}


// [[Rcpp::export]]
Rcpp::List smooth_hgmrfSVcov(arma::vec y, 
                             arma::mat X,
                             arma::mat W,
                             Rcpp::List hyper,
                             double Tol_Par = 1e-2,
                             int maxIt = 500,
                             int Trace = 0) {
  
  arma::vec s = pow(y,2);
  double n = y.n_elem;
  double p = W.n_cols;
  double K = X.n_cols;
  
  double A = hyper["A"];
  double B = hyper["B"];
  double s2 = hyper["s2"];
  double s2beta = hyper["s2beta"];
  
  arma::vec mu_q_h = zeros(n+1);
  arma::vec f = zeros(p);
  arma::mat Sigma_q_h = eye(n+1,n+1);
  arma::vec sigma2_q_h = ones(n+1);
  
  double mu_q_c = 0;
  double sigma2_q_c = 1;
  double mu_q_rho = 0.8;
  double mu_q_rho2 = 0.6;
  double mu_q_s2eta_inv = 3;
  double mu_q_s2eta = 3;
  
  arma::vec mu_q_beta = X.t()*y/n;
  arma::mat Sigma_q_beta = ones(K,K);
  
  arma::vec parOld = zeros(K+3);
  parOld(span(0,K-1)) = mu_q_beta;
  parOld(K) = mu_q_c;
  parOld(K+1) = mu_q_rho;
  parOld(K+2) = mu_q_s2eta;
  
  int conv = 0;
  int it = 0;
  
  while (conv==0) {
    it = it + 1;
    
    arma::vec qparam = zeros(4);
    qparam(0) = mu_q_c;
    qparam(1) = mu_q_rho;
    qparam(2) = mu_q_rho2;
    qparam(3) = mu_q_s2eta_inv;
    
    arma::mat mu_q_Qtilde = tridiag(mu_q_rho2,mu_q_rho,n+1);
    
    arma::vec trBXX = zeros(n);
    for (int t = 0; t < n; t++) trBXX(t) = trace(Sigma_q_beta*X.row(t).t()*X.row(t));
    arma::vec mu_q_s = pow(y-X*mu_q_beta,2) + trBXX;
    
    Rcpp::List opt_out = wand2014W(f,Sigma_q_h,sigma2_q_h,
                                   mu_q_s,W,qparam);
    arma::vec fh = opt_out["f"];
    arma::mat Sh = opt_out["S"];
    arma::vec sh = opt_out["s2"];
    
    f = fh;
    mu_q_h = W*f;
    Sigma_q_h = Sh;
    sigma2_q_h = sh;
    
    sigma2_q_c = 1.0/((2.0*(1-mu_q_rho)+(n-1)*(1.0+mu_q_rho2-2.0*mu_q_rho))*mu_q_s2eta_inv+1.0/s2);
    mu_q_c = sigma2_q_c*mu_q_s2eta_inv*((1.0-mu_q_rho)*(mu_q_h(0)+mu_q_h(n))+(1.0+mu_q_rho2-2.0*mu_q_rho)*sum(mu_q_h(span(1,n-1))));
    
    double A_q_eta = A + 0.5*(n+1);
    arma::vec sq_mu_h = pow(mu_q_h(span(1,n-1))-mu_q_c,2);
    arma::vec cross_mu_h = (mu_q_h(span(0,n-1))-mu_q_c)%(mu_q_h(span(1,n))-mu_q_c);
    double B_q_eta = B + 0.5*(pow(mu_q_h(0)-mu_q_c,2)+pow(mu_q_h(n)-mu_q_c,2)+(1+mu_q_rho2)*sum(sq_mu_h) -
                              2.0*mu_q_rho*sum(cross_mu_h) +
                              (sigma2_q_h(0)+sigma2_q_h(n)+(1+mu_q_rho2)*sum(sigma2_q_h(span(1,n-1)))-2*mu_q_rho*sum(Sigma_q_h.diag(1))) +
                              sigma2_q_c*(2.0*(1.0-mu_q_rho)+(n-1.0)*(1.0+mu_q_rho2-2.0*mu_q_rho)));
    mu_q_s2eta_inv = A_q_eta/B_q_eta;
    mu_q_s2eta = B_q_eta/(A_q_eta-1);
    
    double alpha = sum(sq_mu_h+sigma2_q_c+sigma2_q_h(span(1,n-1)));
    double beta = sum(cross_mu_h+sigma2_q_c+Sigma_q_h.diag(1));
    
    arma::vec out_q_rho = rho_qmoments(alpha,beta,mu_q_s2eta_inv);
    mu_q_rho = out_q_rho(0);
    mu_q_rho2 = out_q_rho(1);
    
    arma::mat H = diagmat(exp(-mu_q_h(span(1,n))+0.5*sigma2_q_h(span(1,n))));
    Sigma_q_beta = inv_sympd(X.t()*H*X+1/s2beta*ones(K,K));
    mu_q_beta = Sigma_q_beta*X.t()*H*y;
    
    arma::vec parNew = zeros(K+3);
    parNew(span(0,K-1)) = mu_q_beta;
    parNew(K) = mu_q_c;
    parNew(K+1) = mu_q_rho;
    parNew(K+2) = mu_q_s2eta;  
    
    if (it > 1) {
      double delta = max(abs((parNew-parOld)/parOld));
      if (delta < Tol_Par) conv = 1;
      if (Trace == 1) cout << "iter:" << it << " error:" << delta << endl;
    }
    if (it > maxIt) conv = 1;
    
    parOld = parNew;
  }
  
  arma::vec theta = zeros(3);
  theta(0) = mu_q_c;
  theta(1) = mu_q_rho;
  theta(2) = mu_q_s2eta;
  
  return Rcpp::List::create(
    Rcpp::Named("mu_q_h") = mu_q_h,
    Rcpp::Named("Sigma_q_h") = Sigma_q_h,
    Rcpp::Named("sigma2_q_h") = sigma2_q_h,
    Rcpp::Named("mu_q_beta") = mu_q_beta,
    Rcpp::Named("Sigma_q_beta") = Sigma_q_beta,
    Rcpp::Named("par") = theta
  );
}
